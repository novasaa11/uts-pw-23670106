package handlers

import (
	"crud-go/config"
	"net/http"
)

func CreateKategori(w http.ResponseWriter, r *http.Request) {
	nama := r.FormValue("nama")
	_, err := config.DB.Exec("INSERT INTO kategori (nama) VALUES (?)", nama)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Write([]byte("Kategori berhasil ditambahkan"))
}
