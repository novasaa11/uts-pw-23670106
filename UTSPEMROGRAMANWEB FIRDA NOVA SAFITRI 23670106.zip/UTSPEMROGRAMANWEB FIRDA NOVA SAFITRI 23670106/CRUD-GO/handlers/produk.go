package handlers

import (
	"encoding/json"
	"crud-go/config"
	"crud-go/models"
	"net/http"
)

func CreateProduk(w http.ResponseWriter, r *http.Request) {
	nama := r.FormValue("nama")
	harga := r.FormValue("harga")
	kategoriID := r.FormValue("kategori_id")

	_, err := config.DB.Exec("INSERT INTO produk (nama, harga, kategori_id) VALUES (?, ?, ?)", nama, harga, kategoriID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Write([]byte("Produk berhasil ditambahkan"))
}

func GetProduk(w http.ResponseWriter, r *http.Request) {
	rows, err := config.DB.Query(`
		SELECT produk.id, produk.nama, produk.harga, kategori.nama
		FROM produk JOIN kategori ON produk.kategori_id = kategori.id
	`)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	defer rows.Close()

	var hasil []models.Produk
	for rows.Next() {
		var p models.Produk
		rows.Scan(&p.ID, &p.Nama, &p.Harga, &p.Kategori)
		hasil = append(hasil, p)
	}

	json.NewEncoder(w).Encode(hasil)
}
